import"./_virtual_wxt-html-plugins-DPbbfBKe.js";console.log("☎️ DevTools Pane: loaded");
